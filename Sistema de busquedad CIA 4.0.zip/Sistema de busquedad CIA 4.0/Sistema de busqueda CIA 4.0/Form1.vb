﻿Imports MySql.Data.MySqlClient
Public Class Form1
#Region "Variables"
    Private cmb As MySqlCommandBuilder
    Dim conexion1 As New MySqlConnection
    Dim datos As New DataSet
    Dim adaptador As New MySqlDataAdapter
    Dim Lista As Byte
#End Region
#Region "Base de Datos"
    Public Sub Conectar()
        Try
            conexion1.ConnectionString = "server=localhost;user=root;password=12345678Dd;database=denunciantes"
            conexion1.Open()
            Dim consulta As String
            consulta = "SELECT * FROM denuncias"
            adaptador = New MySqlDataAdapter(consulta, conexion1)
            datos = New DataSet
            adaptador.Fill(datos, "denuncias")
            DGV.DataSource = datos
            DGV.DataMember = "denuncias"
            MsgBox("Conectado Correctamente")
        Catch ex As Exception
            MsgBox("NO Conectado" + ex.ToString)
            Me.Close()
        End Try
    End Sub
#End Region
#Region "LOAD"
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Conectar()
    End Sub
#End Region
#Region "Agregar Datos"
    Private Sub INGRESAR_Click(sender As Object, e As EventArgs) Handles INGRESAR.Click
        If (numero.Text = "") Or (nombre1.Text = "") Or (nombre2.Text = "") Or (fecha.Text = "") Or (lugar.Text = "") Then
            MsgBox("Error, campos vacios ", MsgBoxStyle.Information, "confirma")
        Else
            Try
                Dim consulta5 As String = "SELECT * FROM denuncias WHERE numero_de_expedientes='" & numero.Text & "'"
                Dim ADAPTADORC As New MySqlDataAdapter(consulta5, conexion1)
                Dim datos As New DataSet
                ADAPTADORC.Fill(datos, "denuncias")
                Lista = datos.Tables("denuncias").Rows.Count
                If Lista <> 0 Then
                    MsgBox("Ya existe esa persona existe en la base de datos", MsgBoxStyle.Information, "confirma")
                    BorrarCampos()
                    MostrarDatos()
                Else
                    Dim ENTRADA As String = "INSERT INTO denuncias(numero_de_expedientes,nombre_del_denunciante,nombre_del_imputado,fecha,lugar)
                   VALUES ('" + numero.Text + "', '" + nombre1.Text + "', '" + nombre2.Text + "', '" + fecha.Text + "', '" + lugar.Text + "')"
                    Dim DT As New DataTable
                    Dim ADAPTADOR As New MySqlDataAdapter(ENTRADA, conexion1)
                    ADAPTADOR.Fill(DT)
                    conexion1.Close()
                    MsgBox("insertado correctamente", MsgBoxStyle.Information, "confirma")
                    BorrarCampos()
                    MostrarDatos()


                End If
            Catch ex As Exception
                MsgBox("Error Critico, no se llenaron los campos", MsgBoxStyle.Critical, "Error" + ex.Message)
            Finally
                conexion1.Dispose()
            End Try
        End If
    End Sub


#End Region
#Region "Modificar datos"
    Private Sub MODIFICAR_Click(sender As Object, e As EventArgs) Handles MODIFICAR.Click
        If conexion1.State = ConnectionState.Closed Then
            conexion1.Open()
        End If
        If (numero.Text = "") Or (nombre1.Text = "") Or (nombre2.Text = "") Or (fecha.Text = "") Or (lugar.Text = "") Then
            MsgBox("No se puede modificar datos, no esta selecionado nada ", MsgBoxStyle.Information, "confirma")
        Else
            Dim comando As New MySqlCommand("UPDATE denuncias Set nombre_del_denunciante='" & nombre1.Text & "',nombre_del_imputado='" & nombre2.Text & "',fecha='" & fecha.Text & "',lugar='" & lugar.Text & "' WHERE numero_de_expedientes=" & Conversion.Int(numero.Text) & "", conexion1)
            'da error por el formato de la fecha
            comando.ExecuteNonQuery()
            MsgBox("Datos Actualizados Correctamente", MsgBoxStyle.Information, "confirma")
            BorrarCampos()
            MostrarDatos()
            INGRESAR.Enabled = True
            If conexion1.State = ConnectionState.Open Then
                conexion1.Close()
            End If
        End If
    End Sub
#End Region
#Region "Borrar Datos"
    Public Sub BorrarCampos()
        numero.Text = ""
        nombre1.Text = ""
        nombre2.Text = ""
        fecha.Text = ""
        lugar.Text = ""
    End Sub
#End Region
#Region "Mostrar datos"
    Public Sub consulta(ByVal sql As String, ByVal tabla As String)
        datos.Tables.Clear()
        adaptador = New MySqlDataAdapter(sql, conexion1)
        cmb = New MySqlCommandBuilder(adaptador)
        adaptador.Fill(datos, tabla)

    End Sub

    Public Sub MostrarDatos()
        consulta("SELECT * FROM denuncias", "denuncias")
        DGV.DataSource = datos.Tables("denuncias")
    End Sub

#End Region
#Region "Datos diseñados"
    Private Sub DGV_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGV.CellClick
        Dim i As Integer = DGV.CurrentRow.Index
        numero.Text = DGV(0, i).Value
        nombre1.Text = DGV(1, i).Value
        nombre2.Text = DGV(2, i).Value
        fecha.Text = DGV(3, i).Value
        lugar.Text = DGV(4, i).Value
        INGRESAR.Enabled = False

    End Sub


#End Region
#Region "NUEVO"
    Private Sub NUEVO_Click(sender As Object, e As EventArgs) Handles NUEVO.Click
        BorrarCampos()
        INGRESAR.Enabled = True
    End Sub


#End Region
#Region "Eliminar datos"
    Private Sub ELIMINAR_Click(sender As Object, e As EventArgs) Handles ELIMINAR.Click
        If conexion1.State = ConnectionState.Closed Then
            conexion1.Open()
        End If
        If (numero.Text = "") Or (nombre1.Text = "") Or (nombre2.Text = "") Or (fecha.Text = "") Or (lugar.Text = "") Then
            MsgBox("No se puede elliminar,no se a selecionado nada  ", MsgBoxStyle.Information, "confirma")

        Else
            Dim comando As New MySqlCommand("DELETE FROM denuncias WHERE numero_de_expedientes=" & Conversion.Int(numero.Text) & "", conexion1)
            comando.ExecuteNonQuery()
            MsgBox("Datos eliminados correctamente", MsgBoxStyle.Information, "confirma")
            BorrarCampos()
            MostrarDatos()
            If conexion1.State = ConnectionState.Open Then
                conexion1.Close()
            End If


        End If



    End Sub


#End Region
#Region "Busqueda"
    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles BUSCAR.TextChanged
        If conexion1.State = ConnectionState.Closed Then
            conexion1.Open()
        End If
        Dim ENTRADA As String = "SELECT * FROM denuncias WHERE nombre_del_denunciante LIKE '%" & BUSCAR.Text & "%' Or numero_de_expedientes LIKE '%" & BUSCAR.Text & "%'"
        Dim ADAPTADOR As New MySqlDataAdapter(ENTRADA, conexion1)
        datos = New DataSet
        ADAPTADOR.Fill(datos)
        If conexion1.State = ConnectionState.Open Then
            conexion1.Close()
            Try
                DGV.DataSource = datos.Tables(0)
            Catch ex As Exception

            End Try
        End If
    End Sub
#End Region














































































End Class
